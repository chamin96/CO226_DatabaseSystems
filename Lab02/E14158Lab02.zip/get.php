<!DOCTYPE html>
<html>
<head>
	<title>The data you just submitted</title>
	<style>
		body.type_2{
			width: 500px;
			border-style:solid; ;
			border-color: black;
			border-width: thin;
		}
	</style>
</head>
<body class="type_2">
	<h1>Your Information System</h1>


	<?php
		$size=$_GET['size'];
		$color=$_GET['color'];
		$cap=$_GET['Cap'];
		$wristBand=$_GET['Wrist_band'];
		$firstName=$_GET['firstName'];
		$lastName=$_GET['lastName'];
		$add_1=$_GET['address_1'];
		$add_2=$_GET['address_2'];
		$add_3=$_GET['address_3'];
		$comments=$_GET['comments'];


		echo "<p>Thank you, ".$firstName. " for your purchases from our web site<br><br>";
		echo "your item colour is : ".$color." & T-Shirt size :".$size."<br><br>";
		echo "Selected items/item are :<br><br>";
		if($cap) echo "* Cap<br>";
		if($wristBand) echo "* Wrist band<br>";
		echo "<br>your items will be sent to :<br><br>";
		echo $firstName." ".$lastName."<br>".$add_1."<br>".$add_2."<br>".$add_3."<br><br>";
		echo "Thank your for submitting your comments. We appriciate it. You said:<br><br>".$comments."<br>";


	?>

</body>
</html>